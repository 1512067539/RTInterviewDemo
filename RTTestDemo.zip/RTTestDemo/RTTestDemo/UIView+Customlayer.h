//
//  UIView+Customlayer.h
//  RTTestDemo
//
//  Created by Mengmeng Wang on 2022/6/20.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN


@interface UIView (Customlayer)

/// 设置圆角
/// @param radius 圆角大小
- (void)setFilletWithCornerRadius:(CGFloat)radius;

/// 设置圆角（带边框颜色）
/// @param radius 圆角大小
/// @param borderWidth 边框宽度
/// @param borderColor 边框颜色
- (void)setFilletWithCornerRadius:(CGFloat)radius borderWidth:(CGFloat)borderWidth borderColor:(UIColor *)borderColor;

/// 设置渐变色
/// @param topColor 顶部颜色
/// @param bottomColor 底部颜色
-(void)setBgColorWithTopColor:(UIColor *)topColor bottomColor:(UIColor *)bottomColor;

@end

NS_ASSUME_NONNULL_END
