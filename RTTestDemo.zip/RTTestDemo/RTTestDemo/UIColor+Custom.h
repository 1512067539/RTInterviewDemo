//
//  UIColor+Custom.h
//  RTTestDemo
//
//  Created by Mengmeng Wang on 2022/6/20.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIColor (Custom)

/// 设置背景色
/// @param colorHexStr 颜色字符串
+ (UIColor *)setBgColorWithHexString:(NSString *)colorHexStr;

@end

NS_ASSUME_NONNULL_END
