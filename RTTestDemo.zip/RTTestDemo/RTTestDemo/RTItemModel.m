//
//  RTItemModel.m
//  RTTestDemo
//
//  Created by Mengmeng Wang on 2022/6/20.
//

#import "RTItemModel.h"

@implementation RTItemModel

- (void)dataAnalysisWithDic:(NSDictionary *)dic{
    self.title = dic[@"title"];
    self.subTitle = dic[@"subTitle"];
    self.selectBtnTitle = dic[@"selectBtnTitle"];
    self.infoStr = dic[@"infoStr"];
}

@end
