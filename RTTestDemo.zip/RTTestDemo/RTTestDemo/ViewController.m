//
//  ViewController.m
//  RTTestDemo
//
//  Created by Mengmeng Wang on 2022/6/20.
//

#import "ViewController.h"
#import "RTItemView.h"
#import "RTAlertView.h"
#import "UIView+Customlayer.h"
#import "UIColor+Custom.h"

@interface ViewController () <RTItemViewDelegate>

@property (nonatomic, strong) UILabel *titleLabel;  //标题

@property (nonatomic, strong) NSMutableArray *itemViewDataArray;  //子视图数据

@property (nonatomic, assign) CGFloat itemView_W;  //itemview的宽度

@property (nonatomic, assign) CGFloat itemView_H;  //itemview的高度

@end

static NSInteger num = 2;  //item个数

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.view setBgColorWithTopColor:[UIColor setBgColorWithHexString:@"#eb8699"] bottomColor:[UIColor setBgColorWithHexString:@"#a65dd1"]];
    
    [self configDefaultData];
    
    [self initSubViews];
}

/// 配置默认数据
- (void)configDefaultData {
    self.itemView_W = ([UIScreen mainScreen].bounds.size.width - 50) / 2.0;
    self.itemView_H = self.itemView_W;
    self.itemViewDataArray = [NSMutableArray arrayWithCapacity:2];
    NSArray *itemDataArray = @[
        @{
            @"title" : @"title1",
            @"subTitle" : @"sdfadfadfadfasfadfasdfasdfasdfasdfasdfasdfasdfasdf",
            @"selectBtnTitle" : @"select1",
            @"infoStr" : @"askdflajdf af ad fajsdf; asdf a sf asdf asd fa sdf ad fa sdf asd fa sdf asd fa sdf asdf asd fa sdf asdf asd fa sdf asdf ad fasd f fadfadfasdasdfasdfasdfasdfasdf \n sdfasdfasdfadfasdfasdfasdfasdfasdasdfasdfasdfasdfasdfasdfasdfasdf"
        },
        @{
            @"title" : @"title2",
            @"subTitle" : @"sdfadfadfadfasfadfasdfasdfasdfasdfasdfasdfasdfasdf2",
            @"selectBtnTitle" : @"select2",
            @"infoStr" : @"askdflajdf af ad fajsdf; asdf a sf asdf asd fa sdf ad fa sdf asd fa sdf asd fa sdf asdf asd fa sdf asdf asd fa sdf asdf ad fasd f fadfadfasdasdfasdfasdfasdfasdf \n sdfasdfasdfadfasdfasdfasdfasdfasdasdfasdfasdfasdfasdfasdfasdfasdf2"
        }
    ];
    
    for (NSDictionary *dic in itemDataArray) {
        RTItemModel *model = [[RTItemModel alloc] init];
        [model dataAnalysisWithDic:dic];
        [self.itemViewDataArray addObject:model];
    }
}

/// 创建子视图
- (void)initSubViews {
    
    self.titleLabel = [[UILabel alloc] init];
    self.titleLabel.frame = CGRectMake(0, 100, [UIScreen mainScreen].bounds.size.width, 80);
    self.titleLabel.font = [UIFont boldSystemFontOfSize:50];
    self.titleLabel.text = @"Hello, world!";
    self.titleLabel.textAlignment = NSTextAlignmentCenter;
    self.titleLabel.textColor = [UIColor blackColor];
    [self.view addSubview:self.titleLabel];
    
    for (NSInteger i = 0; i < num; i++) {
        RTItemView *view = [[RTItemView alloc] initWithFrame:CGRectMake(15 + i * (self.itemView_W + 20), CGRectGetMaxY(self.titleLabel.frame) + 50, self.itemView_W, self.itemView_H)];
        view.delegate = self;
        [view configItemViewWithModel:self.itemViewDataArray[i]];
        [self.view addSubview:view];
    }
}


#pragma mark - RTItemView Delegate
/// 选择按钮点击
-(void)selectBtnClickWithModel:(RTItemModel *)model{
    RTAlertView *alertView = [[RTAlertView alloc] initWithFrame:self.view.frame dataModel:model];
    [self.view addSubview:alertView];
}

@end
