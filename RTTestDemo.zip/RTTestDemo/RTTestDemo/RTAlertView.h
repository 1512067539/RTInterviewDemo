//
//  RTAlertView.h
//  RTTestDemo
//
//  Created by Mengmeng Wang on 2022/6/20.
//

#import <UIKit/UIKit.h>
#import "RTItemModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface RTAlertView : UIView

/// 创建弹框
/// @param frame 弹框frame
/// @param model 弹框数据
- (instancetype)initWithFrame:(CGRect)frame dataModel:(RTItemModel *)model;

@end

NS_ASSUME_NONNULL_END
