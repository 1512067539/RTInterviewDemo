//
//  RTItemModel.h
//  RTTestDemo
//
//  Created by Mengmeng Wang on 2022/6/20.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN


@interface RTItemModel : NSObject

@property (nonatomic, copy) NSString *title;  //标题

@property (nonatomic, copy) NSString *subTitle;  //副标题

@property (nonatomic, copy) NSString *selectBtnTitle;  //选择按钮的title

@property (nonatomic, copy) NSString *infoStr;  //详细信息（弹框显示内容）

/// 数据解析
- (void)dataAnalysisWithDic:(NSDictionary *)dic;

@end

NS_ASSUME_NONNULL_END
