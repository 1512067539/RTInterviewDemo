//
//  AppDelegate.h
//  RTTestDemo
//
//  Created by Mengmeng Wang on 2022/6/20.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

