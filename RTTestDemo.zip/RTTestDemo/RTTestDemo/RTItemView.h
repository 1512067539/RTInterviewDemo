//
//  RTItemView.h
//  RTTestDemo
//
//  Created by Mengmeng Wang on 2022/6/20.
//

#import <UIKit/UIKit.h>
#import "RTItemModel.h"

NS_ASSUME_NONNULL_BEGIN

@protocol RTItemViewDelegate <NSObject>
/// 选择按钮点击
- (void)selectBtnClickWithModel:(RTItemModel *)model;

@end


@interface RTItemView : UIView

@property (nonatomic, weak) id <RTItemViewDelegate> delegate;

/// 配置itemview数据
/// @param model 数据模型
- (void)configItemViewWithModel:(RTItemModel *)model;
@end

NS_ASSUME_NONNULL_END
