//
//  RTItemView.m
//  RTTestDemo
//
//  Created by Mengmeng Wang on 2022/6/20.
//

#import "RTItemView.h"
#import "UIView+Customlayer.h"
#import "UIColor+Custom.h"

@interface RTItemView ()

@property (nonatomic, strong) UILabel *titleLabel;  //标题

@property (nonatomic, strong) UILabel *subTitleLabel;  //副标题

@property (nonatomic, strong) UIButton *selectBtn;  //选择按钮

@property (nonatomic, strong) RTItemModel *currentMode;  //当前的模型数据

@end


@implementation RTItemView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor setBgColorWithHexString:@"#55344c"];
        [self setFilletWithCornerRadius:15];
        
        [self addSubview:self.titleLabel];
        [self addSubview:self.subTitleLabel];
        [self addSubview:self.selectBtn];
    }
    return self;
}

#pragma mark - set/get
- (UILabel *)titleLabel {
    if (!_titleLabel) {
        _titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(20, 20, self.bounds.size.width - 40, 20)];
        _titleLabel.font = [UIFont systemFontOfSize:17];
        _titleLabel.textColor = [UIColor whiteColor];
    }
    return _titleLabel;
}

- (UILabel *)subTitleLabel{
    if (!_subTitleLabel) {
        _subTitleLabel = [[UILabel alloc] initWithFrame:CGRectMake(20, 50, self.bounds.size.width - 40, 50)];
        _subTitleLabel.font = [UIFont systemFontOfSize:14];
        _subTitleLabel.numberOfLines = 0;
        _subTitleLabel.textColor = [UIColor whiteColor];
    }
    return _subTitleLabel;
}

- (UIButton *)selectBtn{
    if (!_selectBtn) {
        _selectBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        _selectBtn.frame = CGRectMake(30, self.bounds.size.height - 60 , self.bounds.size.width - 60, 40);
        [_selectBtn setFilletWithCornerRadius:20 borderWidth:1 borderColor:[UIColor orangeColor]];
        [_selectBtn addTarget:self action:@selector(selectBtnClick:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _selectBtn;
}

#pragma mark - 视图赋值
- (void)configItemViewWithModel:(RTItemModel *)model{
    _currentMode = model;
    self.titleLabel.text = model.title;
    self.subTitleLabel.text = model.subTitle;
    [self.selectBtn setTitle:model.selectBtnTitle forState:UIControlStateNormal];
}

#pragma mark - 选择按钮点击
- (void)selectBtnClick:(UIButton *)btn{
    if ([self.delegate respondsToSelector:@selector(selectBtnClickWithModel:)]) {
        [self.delegate selectBtnClickWithModel:_currentMode];
    }
}

@end
