//
//  UIView+Customlayer.m
//  RTTestDemo
//
//  Created by Mengmeng Wang on 2022/6/20.
//

#import "UIView+Customlayer.h"

@implementation UIView (Customlayer)

- (void)setFilletWithCornerRadius:(CGFloat)radius{
    self.layer.masksToBounds = YES;
    self.layer.cornerRadius = radius;
}

- (void)setFilletWithCornerRadius:(CGFloat)radius borderWidth:(CGFloat)borderWidth borderColor:(UIColor *)borderColor{
    self.layer.masksToBounds = YES;
    self.layer.cornerRadius = radius;
    self.layer.borderColor = borderColor.CGColor;
    self.layer.borderWidth = borderWidth;
}

- (void)setBgColorWithTopColor:(UIColor *)topColor bottomColor:(UIColor *)bottomColor{
    CAGradientLayer *gradientLayer = [CAGradientLayer layer];
    gradientLayer.colors = @[(__bridge id)topColor.CGColor, (__bridge id)bottomColor.CGColor];
    gradientLayer.locations = @[@0.5, @1.0];
    gradientLayer.startPoint = CGPointMake(0, 0);
    gradientLayer.endPoint = CGPointMake(0, 1);
    gradientLayer.frame = self.bounds;
    [self.layer addSublayer:gradientLayer];
}



@end
