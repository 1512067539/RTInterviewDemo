//
//  RTAlertView.m
//  RTTestDemo
//
//  Created by Mengmeng Wang on 2022/6/20.
//

#import "RTAlertView.h"
#import "UIView+Customlayer.h"

typedef NS_ENUM(NSUInteger, RTAlertViewAnimation) {
    RTAlertViewAnimation_Show = 0,  //显示
    RTAlertViewAnimation_Remove,  //移除
};

@interface RTAlertView ()

@property (nonatomic, strong) RTItemModel *currentModel;  //当前的数据模型

@property (nonatomic, strong) UIView *mianView;  //弹层主视图（白色背景）

@property (nonatomic, strong) UILabel *titleLabel;  //标题

@property (nonatomic, strong) UILabel *msgLabel;  //信息

@property (nonatomic, strong) UIButton *trueBtn;  //确认按钮
@end

@implementation RTAlertView

- (instancetype)initWithFrame:(CGRect)frame dataModel:(RTItemModel *)model;
{
    self = [super initWithFrame:frame];
    if (self) {
        
        _currentModel = model;
        self.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0];
        
        [self addSubview:self.mianView];
        [self.mianView addSubview:self.titleLabel];
        [self.mianView addSubview:self.msgLabel];
        [self.mianView addSubview:self.trueBtn];
        
        [self addAnimationWithType:RTAlertViewAnimation_Show];
    }
    return self;
}

#pragma mark - set/get
- (UIView *)mianView{
    if (!_mianView) {
        _mianView = [[UIView alloc] initWithFrame:CGRectMake(30, [UIScreen mainScreen].bounds.size.height, [UIScreen mainScreen].bounds.size.width - 60, [UIScreen mainScreen].bounds.size.width - 60)];
        _mianView.backgroundColor = [UIColor whiteColor];
        [_mianView setFilletWithCornerRadius:20];
    }
    return _mianView;
}

- (UILabel *)titleLabel {
    if (!_titleLabel) {
        _titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(20, 20, self.mianView.bounds.size.width - 40, 20)];
        _titleLabel.font = [UIFont systemFontOfSize:17];
        _titleLabel.textColor = [UIColor blackColor];
        _titleLabel.text = _currentModel.title;
    }
    return _titleLabel;
}

- (UILabel *)msgLabel{
    if (!_msgLabel) {
        _msgLabel = [[UILabel alloc] initWithFrame:CGRectMake(20, 50, self.mianView.bounds.size.width - 40, self.mianView.bounds.size.height - 50 - 40 - 20)];
        _msgLabel.font = [UIFont systemFontOfSize:14];
        _msgLabel.numberOfLines = 0;
        _msgLabel.textColor = [UIColor blackColor];
        _msgLabel.text = _currentModel.infoStr;
        CGSize size = [_msgLabel sizeThatFits:CGSizeMake(self.mianView.bounds.size.width - 40, MAXFLOAT)];
        CGFloat height = MIN(size.height, (self.mianView.bounds.size.height - 50 - 40 - 20));
        _msgLabel.frame = CGRectMake(20, 50, self.mianView.bounds.size.width - 40, height);
    }
    return _msgLabel;
}

- (UIButton *)trueBtn{
    if (!_trueBtn) {
        _trueBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        _trueBtn.frame = CGRectMake(60, self.mianView.bounds.size.height - 60 , self.mianView.bounds.size.width - 120, 40);
        [_trueBtn setFilletWithCornerRadius:20 borderWidth:1 borderColor:[UIColor orangeColor]];
        [_trueBtn setTitle:@"OK" forState:UIControlStateNormal];
        [_trueBtn setTitleColor:[UIColor orangeColor] forState:UIControlStateNormal];
        [_trueBtn addTarget:self action:@selector(trueBtnClick:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _trueBtn;
}

#pragma mark - 确认按钮点击
- (void)trueBtnClick:(UIButton *)btn{
    [self addAnimationWithType:RTAlertViewAnimation_Remove];
}

#pragma mark - 添加动画，animationType动画类型
- (void)addAnimationWithType:(RTAlertViewAnimation)animationType{
    if (animationType == RTAlertViewAnimation_Show) {  //显示
        [UIView animateWithDuration:0.2 animations:^{
            self.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.5];
            self.mianView.center = self.center;
        }];
        return;
    }
    
    //移除
    [UIView animateWithDuration:0.2 animations:^{
        self.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0];
        self.mianView.center = CGPointMake([UIScreen mainScreen].bounds.size.width / 2.0, [UIScreen mainScreen].bounds.size.height + self.mianView.bounds.size.height);
    } completion:^(BOOL finished) {
        [self removeFromSuperview];
    }];
}


- (void)dealloc{
    NSLog(@"RTAlertView - 释放");
}

@end
